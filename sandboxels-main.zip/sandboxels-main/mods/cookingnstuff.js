        logMessage("This mod (cookingnstuff.js) has been moved to talismanadditions.js");
