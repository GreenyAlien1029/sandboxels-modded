logMessage("This mod is deprecated. Please remove it from your mod list, along with any mods that depend on it.")
