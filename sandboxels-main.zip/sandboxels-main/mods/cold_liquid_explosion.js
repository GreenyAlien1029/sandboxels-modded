//Made by SuperASAX or SuperAAX

elements.liquid_tnt = {
    color: "#c92a2a",
    behavior: behaviors.LIQUID,
    behaviorOn: [
        "XX|XX|XX",
        "XX|EX:10|XX",
        "XX|XX|XX",
    ],
    conduct: 1,
    category: "weapons",
    tempLow: -50,
    state: "liquid",
    stateLow: "explosion",
    density: 1630,
    excludeRandom: true,
    alias: "trinitrotoluene"
};
//Made by SuperASAX or SuperAAX