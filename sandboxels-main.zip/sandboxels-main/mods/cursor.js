document.head.insertAdjacentHTML("beforeend",`<style>
    *, button, input, input[type="button"] { cursor: url(https://r74n.com/shapes/png/cursor_full.png), auto; }
</style>`)