        maxPixelCount = settings.maxpixels || Number.MAX_VALUE;
        if (settings.maxpixels === 0) { maxPixelCount = Number.MAX_VALUE; }