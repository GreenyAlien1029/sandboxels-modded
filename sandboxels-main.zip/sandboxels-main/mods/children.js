elements.child =  {
  color: "#ffaa55",
  behavior:  [
    "M2|M2|M2",
    "M2|XX|M2",
    "XX|M1|XX"
],
  tempHigh: 100,
  stateHigh: "cooked_meat",
  category: "life",
  reactions:  {
    "herb":  { elem1: "blood", elem2: "explosion"}
},
};
