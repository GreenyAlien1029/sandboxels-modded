elements.candy.colorPattern = [
		"WWRRRWWRRR",
		"WWRRWWWRRW",
		"WRRRWWRRRW",
		"WRRWWWRRWW",
		"RRRWWRRRWW",
		"RRWWWRRWWW",
		"RRWWRRRWWR",
		"RWWWRRWWWR",
		"RWWRRRWWRR",
		"WWWRRWWWRR",
	]
	elements.candy.colorKey = {"R":"#c92626", "W":"#e3e3e3"}
	elements.candy.color = ["#c92626","#e3e3e3","#c92626","#e3e3e3","#c92626"]
	elements.candy.breakIntoColor = ["#c92626","#e3e3e3"]