// For macOS magic mouse users.

wheelHandle = function(e) {
    e.preventDefault();
};